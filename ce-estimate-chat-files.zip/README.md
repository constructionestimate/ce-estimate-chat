# CE Estimate Chat

A lightweight AI estimator assistant interface.