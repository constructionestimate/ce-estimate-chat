export function parseSpreadsheet(file: File) {
  // Logic to parse Excel and extract material quantities
}