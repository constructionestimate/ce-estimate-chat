# CE Estimate Chat

This project powers the estimating assistant for Construction Estimate using Next.js and OpenAI.