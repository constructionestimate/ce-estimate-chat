export default function ChatWidget() {
  return (
    <div>
      <p>This will be your AI-powered estimating assistant.</p>
    </div>
  );
}