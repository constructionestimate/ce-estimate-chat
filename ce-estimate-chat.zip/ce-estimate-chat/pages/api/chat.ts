export default function handler(req, res) {
  res.status(200).json({ message: "Chatbot backend is connected!" });
}
