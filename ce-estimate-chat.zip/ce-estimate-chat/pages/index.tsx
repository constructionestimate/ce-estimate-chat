import ChatWidget from "../components/ChatWidget";

export default function Home() {
  return (
    <div>
      <h1>Welcome to CE Estimator</h1>
      <ChatWidget />
    </div>
  );
}