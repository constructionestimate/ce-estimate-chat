import React from 'react';

export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Construction Estimate Assistant</h1>
      <p>This is your chatbot UI.</p>
    </div>
  );
}
